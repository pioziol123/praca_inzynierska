Requirements: 

1. SQLAlchemy 

pip install flask-sqlalchemy

2. Flask-Migrate

pip install flask-migrate

3. SQLite or PostgreSQL or MySQL 

4. flask-wtf

pip install flask-wtf

# Resources: 
# https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-iv-database 